import React from "react";
import "./Posts.css";
import Post from "../Post/Post";

const Posts = () => {
    const blogPosts = [
        {
            title: "MARKETING",
            body: `Marketing refers to activities a company undertakes to promote the buying or selling of a product or service. Marketing includes advertising, selling, and delivering products to consumers or other businesses. Some marketing is done by affiliates on behalf of a company.`,
            author: "Jane ",
            imgUrl:
                "https://www.cmtc.com/hubfs/images/blog_images/Marketing_Mix_shutterstock_206722363.jpg#keepProtocol",
        },
        {
            title: "FINANCE",
            body: `Finance is the process of channeling these funds in the form of credit, loans, or invested capital to those economic entities that most need them or can put them to the most productive use. Consumers, business firms, and governments often do not have the funds available to make expenditures, pay their debts, or complete other transactions and must borrow or sell equity to obtain the money they need to conduct their operations. `,
            author: "Peter",
            imgUrl:
                "https://technozee.com/wp-content/uploads/2020/04/PUBLIC-FINANCE-INITIATIVE-800x445.jpg",
        },
        {
            title: "HR",
            body: `Human resources (HR) is the division of a business that is charged with finding, screening, recruiting, and training job applicants, as well as administering employee-benefit programs. HR plays a key role in helping companies deal with a fast-changing business environment and a greater demand for quality employees in the 21st century.`,
            author: "Simon",
            imgUrl:
                "https://www.cenmetrix.lk/assets/img/solutions/human-resources.jpg",
        },
        {
            title: "PRODUCTION",
            body: `A production department is a group of functions within a business that is responsible for the manufacture of goods. This can include just a few specialized functions with all other work outsourced, or a fully functioning department that converts raw materials, assembles components into finished goods, and packages them. `,
            author: "Ann",
            imgUrl:
                "https://media.istockphoto.com/vectors/production-line-vector-id165958933?k=6&m=165958933&s=612x612&w=0&h=ik3JKR3mUHfcVyH0IsQTqjtIMoCkbL_GGwVl09jzxNs=",
        },
    ];

    return (
        <div className="posts-container">
            {blogPosts.map((post, index) => (
                <Post key={index} index={index} post={post} />
            ))}
        </div>
    );
};

export default Posts;